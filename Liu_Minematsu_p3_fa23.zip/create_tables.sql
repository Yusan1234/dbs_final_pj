-- CompanyCode
CREATE TABLE CompanyCode(
    CompanyCode VARCHAR(32),
    CompanyName VARCHAR(32),
    PRIMARY KEY(CompanyCode)
);

-- Customer
CREATE TABLE Customer(
    CustID VARCHAR(32),
    CustFirstName VARCHAR(32),
    CustMiddleInitial VARCHAR(32),
    CustLastName VARCHAR(32),
    CustSuffix VARCHAR(32),
    CustDOB DATE,
    Gender VARCHAR(32),
    PRIMARY KEY(CustID)
);
-- CustomerRelation
CREATE TABLE CustomerRelation(
    CustID VARCHAR(32),
    RelationID VARCHAR(32),
    RelationToCustomer VARCHAR(32),
    StartDate DATE,
    EndDate Date,
    PRIMARY KEY(CustID, RelationID),
    FOREIGN KEY(CustID) REFERENCES Customer(CustID),
    FOREIGN KEY(RelationID) REFERENCES Customer(CustID)
);
-- Account
CREATE TABLE Account(
    AccountID VARCHAR(32),
    AccountName VARCHAR(32),
    AccountName2 VARCHAR(32),
    LocationAddress1 VARCHAR(64),
    LocationAddress2 VARCHAR(64),
    LocationCity VARCHAR(32),
    LocationState VARCHAR(32),
    LocationZip INT,
    CompanyCode VARCHAR(32),
    PRIMARY KEY(AccountID),
    FOREIGN KEY(CompanyCode) REFERENCES CompanyCode(CompanyCode)
);
-- AccountMember
CREATE TABLE AccountMember(
    CustID VARCHAR(32),
    AccountID VARCHAR(32),
    StartDate DATE,
    PRIMARY KEY(CustID, AccountID, StartDate),
    FOREIGN KEY(CustID) REFERENCES Customer(CustID),
    FOREIGN KEY(AccountID) REFERENCES Account(AccountID)
)
-- AccountRelation
CREATE TABLE AccountRelation(
    AccountID VARCHAR(32),
    MasterAcctID VARCHAR(32),
    RelationshipType VARCHAR(32),
    RelationTypeDate DATE,
    PRIMARY KEY(AccountID, MasterAcctID, RelationshipType),
    FOREIGN KEY(AccountID) REFERENCES Account(AccountID),
    FOREIGN KEY(MasterAcctID) REFERENCES Account(AccountID)
);
-- AccountLegacyAlias
CREATE TABLE AccountLegacyAlias(
    AccountID VARCHAR(32),
    AliasSource VARCHAR(64),
    AliasID VARCHAR(32),
    PRIMARY KEY(AccountID, AliasSource, AliasID),
    FOREIGN KEY(AccountID) REFERENCES Account(AccountID)
);
-- AccountAdmin
CREATE TABLE AccountAdmin(
    AdminID VARCHAR(32),
    AdminFirstName VARCHAR(32),
    AdminMiddleInitial VARCHAR(32),
    AdminLastName VARCHAR(32),
    AdminSuffix VARCHAR(32),
    AdminAddress1 VARCHAR(64),
    AdminAddress2 VARCHAR(64),
    AdminCity VARCHAR(32),
    AdminState VARCHAR(32),
    AdminZip INT,
    PRIMARY KEY(AdminID)
);
-- AdminRole
CREATE TABLE AdminRole(
    AdminRole VARCHAR(32),
    AdminDescription VARCHAR(64),
    PRIMARY KEY(AdminRole)
);
-- AcctAcctAdmin
CREATE TABLE AcctAcctAdmin(
    AccountID VARCHAR(32),
    AdminID VARCHAR(32),
    AdminRole VARCHAR(32),
    PRIMARY KEY(AccountID, AdminID),
    FOREIGN KEY(AccountID) REFERENCES Account(AccountID),
    FOREIGN KEY(AdminID) REFERENCES AccountAdmin(AdminID),
    FOREIGN KEY(AdminRole) REFERENCES AdminRole(AdminRole)
)
-- BillingAccount
CREATE TABLE BillingAccount(
    BillingAcctID VARCHAR(32),
    BAcctName VARCHAR(32),
    BAcctName2 VARCHAR(32),
    BillingAddress1 VARCHAR(64),
    BillingAddress2 VARCHAR(64),
    BillingCity VARCHAR(32),
    BillingState VARCHAR(32),
    BillingZip INT,
    PRIMARY KEY(BillingAcctID)
);
-- AccountBillingAccount
CREATE TABLE AccountBillingAccount(
    AccountID VARCHAR(32),
    BillingAcctID VARCHAR(32),
    RelationshipType VARCHAR(32),
    StartDate DATE,
    PRIMARY KEY(AccountID, BillingAcctID, RelationshipType, StartDate),
    FOREIGN KEY(AccountID) REFERENCES Account(AccountID),
    FOREIGN KEY(BillingAcctID) REFERENCES BillingAccount(BillingAcctID)
);
-- BAcctAdmin
CREATE TABLE BAcctAdmin(
    AdminID VARCHAR(32),
    AdminFirstName VARCHAR(32),
    AdminMiddleInitial VARCHAR(32),
    AdminLastName VARCHAR(32),
    AdminSuffix VARCHAR(32),
    AdminAddress1 VARCHAR(64),
    AdminAddress2 VARCHAR(64),
    AdminCity VARCHAR(32),
    AdminState VARCHAR(32),
    AdminZip INT,
    PRIMARY KEY(AdminID)
);
-- BillingAccountBAcctAdmin
CREATE TABLE BillingAccountBAcctAdmin(
    BillingAcctID VARCHAR(32),
    AdminID VARCHAR(32),
    AdminRole VARCHAR(32),
    PRIMARY KEY(BillingAcctID, AdminID),
    FOREIGN KEY(BillingAcctID) REFERENCES BillingAccount(BillingAcctID),
    FOREIGN KEY(AdminID) REFERENCES BAcctAdmin(AdminID),
    FOREIGN KEY(AdminRole) REFERENCES AdminRole(AdminRole)
);


-- AssociateRole
CREATE TABLE AssociateRole(
    AssocRole VARCHAR(32),
    RoleDescription VARCHAR(64),
    PRIMARY KEY(AssocRole)
);

-- Associate
CREATE TABLE Associate(
    AssociateID VARCHAR(32),
    AssociateLastName VARCHAR(32),
    AssociateMiddleInitial VARCHAR(32),
    AssociateFirstName VARCHAR(32),
    AssociateSuffix VARCHAR(32),
    AssociateDOB DATE,
    PRIMARY KEY(AssociateID)
);

-- AssociateRelation
CREATE TABLE AssociateRelation(
    AssociateID VARCHAR(32),
    RelationID VARCHAR(32),
    RelationType VARCHAR(32),
    RelationTypeDate Date,
    PRIMARY KEY(AssociateID, RelationID, RelationType, RelationTypeDate),
    FOREIGN KEY(AssociateID) REFERENCES Associate(AssociateID),
    FOREIGN KEY(RelationID) REFERENCES Associate(AssociateID)
);

-- WritingNumber
CREATE TABLE WritingNumber(
    WritingNumber VARCHAR(32),
    CompanyCode VARCHAR(32),
    AssociateID VARCHAR(32),
    PRIMARY KEY(WritingNumber, CompanyCode),
    FOREIGN KEY(CompanyCode) REFERENCES CompanyCode(CompanyCode),
    FOREIGN KEY(AssociateID) REFERENCES Associate(AssociateID)
);

-- GovernmentAgency
CREATE TABLE GovernmentAgency(
    AgencyID VARCHAR(32),
    AgencyName VARCHAR(32),
    AgencyAddress VARCHAR(32),
    AgencyPhone VARCHAR(32)
    PRIMARY KEY(AgencyID)
)
-- License
CREATE TABLE License (
    LicenseState VARCHAR(32),
    LicenseNumber VARCHAR(32),
    LineOfBusiness VARCHAR(32),
    AgencyID VARCHAR(32),
    IssueDate Date,
    ExpirationDate Date,
    PRIMARY KEY(LicenseState, LicenseNumber, LineOfBusiness, AgencyID),
    FOREIGN KEY(AgencyID) REFERENCES GovernmentAgency(AgencyID)
);
-- LicenseWritingNumber
CREATE TABLE LicenseWritingNumber(
    WritingNumber VARCHAR(32),
    CompanyCode VARCHAR(32),
    LicenseState VARCHAR(32),
    LicenseNumber VARCHAR(32),
    LineOfBusiness VARCHAR(32),
    AgencyID VARCHAR(32),
    PRIMARY KEY(WritingNumber, CompanyCode, LicenseState, LicenseNumber, LineOfBusiness, AgencyID),
    FOREIGN KEY(WritingNumber, CompanyCode) REFERENCES WritingNumber(WritingNumber, CompanyCode),
    FOREIGN KEY(LicenseState, LicenseNumber, LineOfBusiness, AgencyID) REFERENCES License(LicenseState, LicenseNumber, LineOfBusiness, AgencyID),
);

-- ManagerContract
CREATE TABLE ManagerContract(
    SitCode VARCHAR(32),
    CompanyCode VARCHAR(32),
    WritingNumber VARCHAR(32),
    IssueDate DATE,
    PRIMARY KEY(Sitcode, CompanyCode, WritingNumber, IssueDate),
    FOREIGN key(WritingNumber, CompanyCode) REFERENCES WritingNumber(WritingNumber, CompanyCode),
);

-- AccountAssociate
CREATE TABLE AccountAssociate(
    AccountID VARCHAR(32),
    SitCode VARCHAR(32),
    CompanyCode VARCHAR(32),
    WritingNumber VARCHAR(32),
    IssueDate DATE,
    StartDate DATE,
    AssocRole VARCHAR(32),
    StopDate DATE,
    PRIMARY KEY(AccountID, Sitcode, CompanyCode, WritingNumber, IssueDate, StartDate),
    FOREIGN KEY(AccountID) REFERENCES Account(AccountID),
    FOREIGN KEY(SitCode, CompanyCode, WritingNumber, IssueDate) REFERENCES ManagerContract(SitCode, CompanyCode, WritingNumber, IssueDate),
    FOREIGN KEY(AssocRole) REFERENCES AssociateRole(AssocRole)
);

-- AssociateService
CREATE TABLE AssociateService(
    AccountID VARCHAR(32),
    SitCode VARCHAR(32),
    CompanyCode VARCHAR(32),
    WritingNumber VARCHAR(32),
    IssueDate DATE,
    StartDate DATE,
    AssocServiceRole VARCHAR(32),
    LastServiceDate DATE,
    ServiceType VARCHAR(32),
    PRIMARY KEY(AccountID, Sitcode, CompanyCode, WritingNumber, IssueDate, StartDate, AssocServiceRole, LastServiceDate),
    FOREIGN KEY(AccountID, SitCode, CompanyCode, WritingNumber, IssueDate, StartDate) REFERENCES AccountAssociate(AccountID, SitCode, CompanyCode, WritingNumber, IssueDate, StartDate),
);
-- Product
CREATE TABLE Product(
    LineOfBusiness VARCHAR(32),
    ProductDescription VARCHAR(64),
    PRIMARY KEY(LineOfBusiness)
);

-- ProductSeries
CREATE TABLE ProductSeries(
    LineOfBusiness VARCHAR(32),
    SeriesName VARCHAR(32),
    SeriesDescription VARCHAR(64),
    PRIMARY KEY(LineOfBusiness, SeriesName),
    FOREIGN KEY(LineOfBusiness) REFERENCES Product(LineOfBusiness)
);

-- ProductPlan
CREATE TABLE ProductPlan(
    LineOfBusiness VARCHAR(32),
    SeriesName VARCHAR(32),
    PlanName VARCHAR(32),
    PlanDescription VARCHAR(64),
    PRIMARY KEY(LineOfBusiness, SeriesName, PlanName),
    FOREIGN KEY(LineOfBusiness, SeriesName) REFERENCES ProductSeries(LineOfBusiness, SeriesName),
);

-- ProductRider
CREATE TABLE ProductRider(
    LineOfBusiness VARCHAR(32),
    SeriesName VARCHAR(32),
    PlanName VARCHAR(32),
    RiderName VARCHAR(32),
    RiderDescription VARCHAR(64),
    PRIMARY KEY(LineOfBusiness, SeriesName, PlanName, RiderName),
    FOREIGN KEY(LineOfBusiness, SeriesName, PlanName) REFERENCES ProductPlan(LineOfBusiness, SeriesName, PlanName)
);

-- Contract
CREATE TABLE Contract(
    ContractNumber VARCHAR(32),
    LineOfBusiness VARCHAR(32),
    SeriesName VARCHAR(32),
    PlanName VARCHAR(32),
    PRIMARY KEY(ContractNumber, LineOfBusiness, SeriesName, PlanName),
    FOREIGN KEY(LineOfBusiness, SeriesName, PlanName) REFERENCES ProductPlan(LineOfBusiness, SeriesName, PlanName)
);

-- ContractBenefit
CREATE TABLE ContractBenefit(
    ContractNumber VARCHAR(32),
    LineOfBusiness VARCHAR(32),
    SeriesName VARCHAR(32),
    PlanName VARCHAR(32),
    RiderName VARCHAR(32),
    PRIMARY KEY(ContractNumber, LineOfBusiness, SeriesName, PlanName, RiderName),
    FOREIGN KEY(ContractNumber, LineOfBusiness, SeriesName, PlanName) REFERENCES Contract(ContractNumber,LineOfBusiness, SeriesName, PlanName),
    FOREIGN KEY(LineOfBusiness, SeriesName, PlanName,RiderName) REFERENCES ProductRider(LineOfBusiness, SeriesName, PlanName, RiderName)
);

-- ContractPremium
CREATE TABLE ContractPremium(
    PremiumCode VARCHAR(32),
    ContractNumber VARCHAR(32),
    LineOfBusiness VARCHAR(32),
    SeriesName VARCHAR(32),
    PlanName VARCHAR(32),
    RiderName VARCHAR(32),
    AnnualizedPremium REAL,
    PRIMARY KEY(PremiumCode, ContractNumber, LineOfBusiness, SeriesName, PlanName, RiderName),
    FOREIGN KEY(ContractNumber, LineOfBusiness, SeriesName, PlanName, RiderName) REFERENCES ContractBenefit(ContractNumber, LineOfBusiness, SeriesName, PlanName, RiderName),
);

-- BenefitForBenefitingParty
CREATE TABLE BenefitForBenefitingParty(
    CustID VARCHAR(32),
    PremiumCode VARCHAR(32),
    ContractNumber VARCHAR(32),
    LineOfBusiness VARCHAR(32),
    SeriesName VARCHAR(32),
    PlanName VARCHAR(32),
    RiderName VARCHAR(32),
    PRIMARY KEY(CustID, PremiumCode, ContractNumber, LineOfBusiness, SeriesName, PlanName, RiderName),
    FOREIGN KEY(CustID) REFERENCES Customer(CustID),
    FOREIGN KEY(PremiumCode, ContractNumber, LineOfBusiness, SeriesName, PlanName, RiderName) REFERENCES ContractPremium(PremiumCode, ContractNumber, LineOfBusiness, SeriesName, PlanName, RiderName),
);

-- ContractingPartyRole
CREATE TABLE ContractingPartyRole(
    CPRole VARCHAR(32),
    CPDescription VARCHAR(64),
    PRIMARY KEY(CPRole),
)

-- ContractingPartyInRole
CREATE TABLE ContractingPartyInRole(
    CustID VARCHAR(32),
    ContractNumber VARCHAR(32),
    LineOfBusiness VARCHAR(32),
    SeriesName VARCHAR(32),
    PlanName VARCHAR(32),
    CPRole VARCHAR(32),
    PRIMARY KEY(CustID, ContractNumber, LineOfBusiness, SeriesName, PlanName),
    FOREIGN KEY(CustID) REFERENCES Customer(CustID),
    FOREIGN KEY(ContractNumber, LineOfBusiness, SeriesName, PlanName) REFERENCES Contract(ContractNumber, LineOfBusiness, SeriesName, PlanName),
);

-- PremiumMgmtContract
CREATE TABLE PremiumMgmtContract(
    SitCode VARCHAR(32),
    CompanyCode VARCHAR(32),
    WritingNumber VARCHAR(32),
    IssueDate DATE,
    PremiumCode VARCHAR(32),
    ContractNumber VARCHAR(32),
    LineOfBusiness VARCHAR(32),
    SeriesName VARCHAR(32),
    PlanName VARCHAR(32),
    RiderName VARCHAR(32),
    Amount REAL,
    CommissionRate REAL,
    PRIMARY KEY(Sitcode, CompanyCode, WritingNumber, IssueDate, PremiumCode, ContractNumber, LineOfBusiness, SeriesName, PlanName, RiderName),
    FOREIGN KEY(SitCode, CompanyCode, WritingNumber, IssueDate) REFERENCES ManagerContract(SitCode, CompanyCode, WritingNumber, IssueDate),
    FOREIGN KEY(PremiumCode, ContractNumber, LineOfBusiness, SeriesName, PlanName, RiderName) REFERENCES ContractPremium(PremiumCode, ContractNumber, LineOfBusiness, SeriesName, PlanName, RiderName),
)